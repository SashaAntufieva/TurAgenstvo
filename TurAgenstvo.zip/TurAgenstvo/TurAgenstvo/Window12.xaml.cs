﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace TurAgenstvo
{
    public partial class Window12 : Window
    {
        public Window12()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [ID], [Фамилия], [Имя], [Отчество], [Номер телефона], [E-mail], [Пароль] FROM [Agenstvo].[dbo].[Admin]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                Adm.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window9 window9 = new Window9();
            window9.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_idt = Convert.ToInt32(ID.Text);
                string id_kt = F.Text;
                string id_ott = I.Text;
                string id_prt = O.Text;
                string id_vtt = N.Text;
                string id_izt = E.Text;
                string id_otel = P.Text;
                
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string cmdTxt = $"INSERT INTO Agent (ID, Фамилия, Имя, Отчество, [Номер телефона], [E-mail], Пароль) VALUES ('{id_idt}', '{id_kt}', '{id_ott}', '{id_prt}', '{id_vtt}', '{id_izt}', '{id_otel}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                ID.Clear(); F.Clear(); I.Clear(); O.Clear(); N.Clear(); E.Clear(); P.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ID.Clear(); F.Clear(); I.Clear(); O.Clear(); N.Clear(); E.Clear(); P.Clear();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_u = Convert.ToInt32(Ud.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Admin WHERE ID = '{id_u}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                Ud.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                Ud.Clear();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            LoadData();
        }
    }
}
