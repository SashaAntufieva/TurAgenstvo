﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace TurAgenstvo
{
    
    public partial class Window7 : Window
    {
        public Window7()
        {
            InitializeComponent();
            LoadData();
        }


        //таблица

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [ID], [ID тура], [ID агента], [Фамилия клиента], [Имя клиента], [Номер телефона клиента], [E-mail клиента], [Количество купленных билетов], [Цена] FROM [Agenstvo].[dbo].[Bron]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                BronAgens.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

       //назад

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window9 window9 = new Window9();
            window9.Show();
            this.Close();
        }

        //добавление

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_idtb = Convert.ToInt32(IDTB.Text);
                int id_idtur = Convert.ToInt32(IDTur.Text);
                int id_idag = Convert.ToInt32(IDAg.Text);
                string id_fam = Fam.Text;
                string id_im = Im.Text;
                string id_nomtel = NomTel.Text;
                string id_email =Email.Text;
                string id_klb = Klb.Text;
                string id_zenab = Zenab.Text;

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string cmdTxt = $"INSERT INTO Bron (ID, [ID тура], [ID агента], [Фамилия клиента], [Имя клиента], [Номер телефона клиента], [E-mail клиента], [Количество купленных билетов], Цена) VALUES ('{id_idtb}', '{id_idtur}', '{id_idag}', '{id_fam}', '{id_im}', '{id_nomtel}', '{id_email}', '{id_klb}', '{id_zenab}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDTB.Clear(); IDTur.Clear(); IDAg.Clear(); Fam.Clear(); Im.Clear(); NomTel.Clear(); Email.Clear(); Klb.Clear(); Zenab.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDTB.Clear(); IDTur.Clear(); IDAg.Clear(); Fam.Clear(); Im.Clear(); NomTel.Clear(); Email.Clear(); Klb.Clear(); Zenab.Clear();
            }
        }
        
        //обновление

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        //удаление

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_idud = Convert.ToInt32(IDud.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Bron WHERE ID = '{id_idud}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDud.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDud.Clear();
            }
        }

        //изменение

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(IDStar.Text);
                int id1 = Convert.ToInt32(IDTS.Text);
                int id2 = Convert.ToInt32(IDAS.Text);
                string ks = FamS.Text;
                string ots = ImS.Text;
                string prs = NomTS.Text;
                string vts = EmS.Text;

                int newid = Convert.ToInt32(IDnov.Text);
                int newid1 = Convert.ToInt32(IDTurN.Text);
                int newid2 = Convert.ToInt32(IDAgN.Text);
                string newks = FamN.Text;
                string newots = ImN.Text;
                string newprs = NomTN.Text;
                string newvts = EmN.Text;

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string cmdTxt1 = $"UPDATE Bron SET [ID тура] = '{newid1}' WHERE ID = '{id}'";
                SqlCommand command1 = new SqlCommand(cmdTxt1, connection);
                string cmdTxt2 = $"UPDATE Bron SET [ID агента] = '{newid2}' WHERE ID = '{id}'";
                SqlCommand command2 = new SqlCommand(cmdTxt2, connection);
                string cmdTxt3 = $"UPDATE Bron SET [Фамилия клента] = '{newks}' WHERE ID = '{id}'";
                SqlCommand command3 = new SqlCommand(cmdTxt3, connection);
                string cmdTxt4 = $"UPDATE Bron SET [Имя клиента] = '{newots}' WHERE ID = '{id}'";
                SqlCommand command4 = new SqlCommand(cmdTxt4, connection);
                string cmdTxt5 = $"UPDATE Bron SET [Номер телефона клиента] = '{newprs}' WHERE ID = '{id}'";
                SqlCommand command5 = new SqlCommand(cmdTxt5, connection);
                string cmdTxt6 = $"UPDATE Bron SET [E-mail клиента] = '{newvts}' WHERE ID = '{id}'";
                SqlCommand command6 = new SqlCommand(cmdTxt6, connection);

                command1.ExecuteNonQuery(); command2.ExecuteNonQuery(); command3.ExecuteNonQuery(); command4.ExecuteNonQuery(); command5.ExecuteNonQuery(); command6.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!", "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDStar.Clear(); IDTS.Clear(); IDAS.Clear(); FamS.Clear(); ImS.Clear(); NomTS.Clear(); EmS.Clear();
                IDnov.Clear(); IDTurN.Clear(); IDAgN.Clear(); FamN.Clear(); ImN.Clear(); NomTN.Clear(); EmN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Ok1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ids = Convert.ToString(IDStar.Text);
                string idn = Convert.ToString(IDnov.Text);
                string ssql = $"UPDATE Bron SET [ID] = '{idn}' WHERE [ID] = '{ids}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                IDStar.Clear(); IDnov.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDStar.Clear(); IDnov.Clear();
            }
        }

        private void Ok2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string idts = Convert.ToString(IDTS.Text);
                string idtn = Convert.ToString(IDTurN.Text);
                string ssql1 = $"UPDATE Bron SET [ID тура] = '{idtn}' WHERE [ID тура] = '{idts}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql1, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                IDTS.Clear(); IDTurN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDTS.Clear(); IDTurN.Clear();
            }
        }

        private void Ok3_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string idas = Convert.ToString(IDAS.Text);
                string idan = Convert.ToString(IDAgN.Text);
                string ssql2 = $"UPDATE Bron SET [ID агента] = '{idan}' WHERE [ID агента] = '{idas}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql2, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                IDAS.Clear(); IDAgN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDAS.Clear(); IDAgN.Clear();
            }
        }

        private void Ok4_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string fams = Convert.ToString(FamS.Text);
                string famn = Convert.ToString(FamN.Text);
                string ssql3 = $"UPDATE Bron SET [Фамилия клиента] = '{famn}' WHERE [Фамилия клиента] = '{fams}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql3, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                FamS.Clear(); FamN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                FamS.Clear(); FamN.Clear();
            }
        }

        private void Ok5_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ims = Convert.ToString(ImS.Text);
                string imn = Convert.ToString(ImN.Text);
                string ssql4 = $"UPDATE Bron SET [Имя клиента] = '{imn}' WHERE [Имя клиента] = '{ims}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql4, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ImS.Clear(); ImN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ImS.Clear(); ImN.Clear();
            }
        }

        private void Ok6_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string nts = Convert.ToString(NomTS.Text);
                string ntn = Convert.ToString(NomTN.Text);
                string ssql5 = $"UPDATE Bron SET [Номер телефона клиента] = '{ntn}' WHERE [Номер телефона клиента] = '{nts}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql5, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                NomTS.Clear(); NomTN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                NomTS.Clear(); NomTN.Clear();
            }
        }

        private void Ok7_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ems = Convert.ToString(EmS.Text);
                string emn = Convert.ToString(EmN.Text);
                string ssql6 = $"UPDATE Bron SET [E-mail клиента] = '{emn}' WHERE [E-mail клиента] = '{ems}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql6, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                EmS.Clear(); EmN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                EmS.Clear(); EmN.Clear();
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            try
            {
                string kls = Convert.ToString(Kls.Text);
                string kln = Convert.ToString(Kln.Text);
                string ssql7 = $"UPDATE Bron SET [Количество купленных билетов] = '{kln}' WHERE [Количество купленных билетов] = '{kls}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql7, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                Kls.Clear(); Kln.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                Kls.Clear(); Kln.Clear();
            }
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            try
            {
                string zes = Convert.ToString(Zes.Text);
                string zen = Convert.ToString(Zen.Text);
                string ssql8 = $"UPDATE Bron SET [Цена] = '{zen}' WHERE [Цена] = '{zes}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Agenstvo; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql8, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                Zes.Clear(); Zen.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                Zes.Clear(); Zen.Clear();
            }
        }
    }
}
