﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace TurAgenstvo
{
    
    public partial class Window6 : Window
    {
        public Window6()
        {
            InitializeComponent();
        }

        //+
        private void nazvhag_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        
        //+
        public static DataTable Select(string selectSQL) // подключение к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");

            SqlConnection connection = new SqlConnection(@"Data Source=.\SQLEXPRESS; Initial Catalog=Agenstvo; Integrated Security=True");
            connection.Open();

            SqlCommand command = connection.CreateCommand();
            command.CommandText = selectSQL;

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            adapter.Fill(dataTable);
            return dataTable;

        }

        private void vhag_Click(object sender, RoutedEventArgs e)
        {
            if (LogInTextBox.Text.Length > 0) // проверяем введён ли логин
            {
                if (PasswordTextBox.Text.Length > 0) // проверяем введён ли пароль
                { // ищем в базе данных пользователя с такими данными
                    DataTable dt_admin = Select("SELECT * FROM [dbo].[Agent] WHERE [ID] = '" + LogInTextBox.Text + "' AND [Пароль] = '" + PasswordTextBox.Text + "'");

                    if (dt_admin.Rows.Count > 0) // если такая запись существует
                    {
                        Window9 window9 = new Window9();
                        window9.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль!"); // выводим ошибку при неверных пароле и логине
                    }
                }
                else
                {
                    MessageBox.Show("Введите пароль!"); // выводим ошибку, если не введён пароль
                }

            }
            else
            {
                MessageBox.Show("Введите логин!"); // выводим ошибку, если не введён логин
            }
        }
    }
}
