﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace TurAgenstvo
{
    /// <summary>
    /// Логика взаимодействия для Window8.xaml
    /// </summary>
    public partial class Window8 : Window
    {
        public Window8()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [ID], [Откуда], [Куда], [Дата отправления], [Дата отправления обратно], [Время вылета], [Время вылета обратно], [Отель], [Всё включено], [Питание], [Цена], [Количество билетов] FROM [Agenstvo].[dbo].[Tur]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                TurAgens1.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        //добавление

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_idt = Convert.ToInt32(IDt.Text);
                string id_otk = Otk.Text;
                string id_kt = Kt.Text;
                string id_ott = Ott.Text;
                string id_prt = Prt.Text;
                string id_vtt = VTt.Text;
                string id_izt = Izt.Text;
                string id_otel = Otel.Text;
                string id_vvkl = VVkl.Text;
                string id_pit = Pit.Text;
                string id_zena = Zena.Text;
                string id_klb = KlB.Text;

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string cmdTxt = $"INSERT INTO Tur (ID, Откуда, Куда, [Дата отправления], [Дата отправления обратно], [Время вылета], [Время вылета обратно], Отель, [Всё включено], Питание, Цена, [Количество билетов]) VALUES ('{id_idt}', '{id_otk}', '{id_kt}', '{id_ott}', '{id_prt}', '{id_vtt}', '{id_izt}', '{id_otel}', '{id_vvkl}', '{id_pit}', '{id_zena}', '{id_klb}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDt.Clear(); Otk.Clear(); Kt.Clear(); Ott.Clear(); Prt.Clear(); VTt.Clear(); Izt.Clear(); Otel.Clear(); VVkl.Clear(); Pit.Clear(); Zena.Clear(); KlB.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDt.Clear(); Otk.Clear(); Kt.Clear(); Ott.Clear(); Prt.Clear(); VTt.Clear(); Izt.Clear(); Otel.Clear(); VVkl.Clear(); Pit.Clear(); Zena.Clear(); KlB.Clear();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_u = Convert.ToInt32(ud.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Tur WHERE ID = '{id_u}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                ud.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ud.Clear();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(IDS.Text);
                string otks = Otks.Text;
                string ks = KS.Text;
                string ots = Ots.Text;
                string prs = Prs.Text;
                string vts = Vts.Text;
                string izs = Izs.Text;
                string otels = Otels.Text;
                string vvkln = Vvkls.Text;
                string pits = Pits.Text;
                string zenas = Zenas.Text;
                string klbs = Klbs.Text;

                int newid = Convert.ToInt32(IDN.Text);
                string otkn = Otkn.Text;
                string newks = KN.Text;
                string newots = Otn.Text;
                string newprs = Prn.Text;
                string newvts = Vtn.Text;
                string newizs = Izn.Text;
                string newotels = Oteln.Text;
                string newvvkln = Vvkln.Text;
                string newpits = Pitn.Text;
                string newzenas = Zenan.Text;
                string klbn = Klbn.Text;

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string cmdTxt1 = $"UPDATE Tur SET Откуда = '{otkn}' WHERE ID = '{id}'";
                SqlCommand command1 = new SqlCommand(cmdTxt1, connection);
                string cmdTxt2 = $"UPDATE Tur SET Куда = '{newks}' WHERE ID = '{id}'";
                SqlCommand command2 = new SqlCommand(cmdTxt2, connection);
                string cmdTxt3 = $"UPDATE Tur SET [Дата отправления] = '{newots}' WHERE ID = '{id}'";
                SqlCommand command3 = new SqlCommand(cmdTxt3, connection);
                string cmdTxt4 = $"UPDATE Tur SET [Дата отправления обратно] = '{newprs}' WHERE ID = '{id}'";
                SqlCommand command4 = new SqlCommand(cmdTxt4, connection);
                string cmdTxt5 = $"UPDATE Tur SET [Время вылета] = '{newvts}' WHERE ID = '{id}'";
                SqlCommand command5 = new SqlCommand(cmdTxt5, connection);
                string cmdTxt6 = $"UPDATE Tur SET [Время вылета обратно] = '{newizs}' WHERE ID = '{id}'";
                SqlCommand command6 = new SqlCommand(cmdTxt6, connection);
                string cmdTxt7 = $"UPDATE Tur SET Отель = '{newotels}' WHERE ID = '{id}'";
                SqlCommand command7 = new SqlCommand(cmdTxt7, connection);
                string cmdTxt8 = $"UPDATE Tur SET [Всё включено] = '{newvvkln}' WHERE ID = '{id}'";
                SqlCommand command8 = new SqlCommand(cmdTxt8, connection);
                string cmdTxt9 = $"UPDATE Tur SET Питание = '{newpits}' WHERE ID = '{id}'";
                SqlCommand command9 = new SqlCommand(cmdTxt9, connection);
                string cmdTxt10 = $"UPDATE Tur SET Цена = '{newzenas}' WHERE ID = '{id}'";
                SqlCommand command10 = new SqlCommand(cmdTxt10, connection);
                string cmdTxt11 = $"UPDATE Tur SET [Количество билетов] = '{klbn}' WHERE ID = '{id}'";
                SqlCommand command11 = new SqlCommand(cmdTxt11, connection);

                command1.ExecuteNonQuery(); command2.ExecuteNonQuery(); command3.ExecuteNonQuery(); command4.ExecuteNonQuery(); command5.ExecuteNonQuery(); command6.ExecuteNonQuery(); command7.ExecuteNonQuery(); command8.ExecuteNonQuery(); command9.ExecuteNonQuery(); command10.ExecuteNonQuery(); command11.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!", "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);


                IDS.Clear(); Otks.Clear(); KS.Clear(); Ots.Clear(); Prs.Clear(); Vts.Clear(); Izs.Clear(); Otels.Clear(); Vvkls.Clear(); Pits.Clear(); Zenas.Clear(); Klbs.Clear();
                IDN.Clear(); Otkn.Clear(); KN.Clear(); Otn.Clear(); Prn.Clear(); Vtn.Clear(); Izn.Clear(); Oteln.Clear(); Vvkln.Clear(); Pitn.Clear(); Zenan.Clear(); Klbn.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window9 window9 = new Window9();
            window9.Show();
            this.Close();
        }

        private void TurAgens1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
