﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace TurAgenstvo
{
    
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        public static DataTable Select(string selectSQL) // подключение к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");

            SqlConnection connection = new SqlConnection(@"Data Source=.\SQLEXPRESS; Initial Catalog=Agenstvo; Integrated Security=True");
            connection.Open();

            SqlCommand command = connection.CreateCommand();
            command.CommandText = selectSQL;

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            adapter.Fill(dataTable);
            return dataTable;

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (EmailTextBox.Text.Length > 0) // проверяем введён ли логин
            {
                if (ParolPTextBox.Text.Length > 0) // проверяем введён ли пароль
                { // ищем в базе данных пользователя с такими данными
                    DataTable dt_admin = Select("SELECT * FROM [dbo].[Polzovatel] WHERE [E-mail] = '" + EmailTextBox.Text + "' AND [Пароль] = '" + ParolPTextBox.Text + "'");

                    if (dt_admin.Rows.Count > 0) // если такая запись существует
                    {
                        Window3 window3 = new Window3();
                        window3.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль!"); // выводим ошибку
                    }
                }
                else
                {
                    MessageBox.Show("Введите пароль!"); // выводим ошибку
                }

            }
            else
            {
                MessageBox.Show("Введите логин!"); // выводим ошибку
            }
        }

        
    }
}
