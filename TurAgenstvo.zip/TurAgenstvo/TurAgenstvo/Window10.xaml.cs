﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace TurAgenstvo
{
    
    public partial class Window10 : Window
    {
        public Window10()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [ID], [Фамилия], [Имя], [Отчество], [Номер телефона], [Должность], [Адрес], [E-mail], [Пароль] FROM [Agenstvo].[dbo].[Agent]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                Sotr.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_i = Convert.ToInt32(IDS.Text);
                string id_fam = Fam.Text;
                string id_im = Im.Text;
                string id_ot = Ot.Text;
                string id_nt = NT.Text;
                string id_dol = Dol.Text;
                string id_adr = Adr.Text;
                string id_em = Em.Text;
                string id_par = Par.Text;

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string cmdTxt = $"INSERT INTO Agent (ID, Фамилия, Имя, Отчество, [Номер телефона], Должность, Адрес, [E-mail], Пароль) VALUES ('{id_i}', '{id_fam}', '{id_im}', '{id_ot}', '{id_nt}', '{id_dol}', '{id_adr}', '{id_em}', '{id_par}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDS.Clear(); Fam.Clear(); Im.Clear(); Ot.Clear(); NT.Clear(); Dol.Clear(); Adr.Clear(); Em.Clear(); Par.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDS.Clear(); Fam.Clear(); Im.Clear(); Ot.Clear(); NT.Clear(); Dol.Clear(); Adr.Clear(); Em.Clear(); Par.Clear();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                int id_ud = Convert.ToInt32(Ud.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Agent WHERE ID = '{id_ud}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                Ud.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                Ud.Clear();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window9 window9 = new Window9();
            window9.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(IDSt.Text);
                string ks = Fs.Text;
                string ots = Ims.Text;
                string prs = Os.Text;
                string vts = NTs.Text;
                string izs = Ds.Text;
                string otels = Ads.Text;
                string vvkln = Ems.Text;
                string pits = Ps.Text;

                int newid = Convert.ToInt32(IDN.Text);
                string newks = Fn.Text;
                string newots = Imn.Text;
                string newprs = On.Text;
                string newvts = NTn.Text;
                string newizs = Dn.Text;
                string newotels = Adn.Text;
                string newvvkln = Emn.Text;
                string newpits = Pn.Text;

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Agenstvo; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string cmdTxt1 = $"UPDATE Agent SET Фамилия = '{newks}' WHERE ID = '{id}'";
                SqlCommand command1 = new SqlCommand(cmdTxt1, connection);
                string cmdTxt2 = $"UPDATE Agent SET Имя = '{newots}' WHERE ID = '{id}'";
                SqlCommand command2 = new SqlCommand(cmdTxt2, connection);
                string cmdTxt3 = $"UPDATE Agent SET Отчество = '{newprs}' WHERE ID = '{id}'";
                SqlCommand command3 = new SqlCommand(cmdTxt3, connection);
                string cmdTxt4 = $"UPDATE Agent SET [Номер телефона] = '{newvts}' WHERE ID = '{id}'";
                SqlCommand command4 = new SqlCommand(cmdTxt4, connection);
                string cmdTxt5 = $"UPDATE Agent SET Должность = '{newizs}' WHERE ID = '{id}'";
                SqlCommand command5 = new SqlCommand(cmdTxt5, connection);
                string cmdTxt6 = $"UPDATE Agent SET Адрес = '{newotels}' WHERE ID = '{id}'";
                SqlCommand command6 = new SqlCommand(cmdTxt6, connection);
                string cmdTxt7 = $"UPDATE Agent SET [E-mail] = '{newvvkln}' WHERE ID = '{id}'";
                SqlCommand command7 = new SqlCommand(cmdTxt7, connection);
                string cmdTxt8 = $"UPDATE Agent SET Пароль = '{newpits}' WHERE ID = '{id}'";
                SqlCommand command8 = new SqlCommand(cmdTxt8, connection);

                command1.ExecuteNonQuery(); command2.ExecuteNonQuery(); command3.ExecuteNonQuery(); command4.ExecuteNonQuery(); command5.ExecuteNonQuery(); command6.ExecuteNonQuery(); command7.ExecuteNonQuery(); command8.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!", "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDSt.Clear(); Fs.Clear(); Ims.Clear(); Os.Clear(); NTs.Clear(); Ds.Clear(); Ads.Clear(); Ems.Clear(); Ps.Clear();
                IDN.Clear(); Fn.Clear(); Imn.Clear(); On.Clear(); NTn.Clear(); Dn.Clear(); Adn.Clear(); Emn.Clear(); Pn.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
